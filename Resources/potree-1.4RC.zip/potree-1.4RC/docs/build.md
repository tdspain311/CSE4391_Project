
# How to build the library

## Installation

Make sure you have [node.js](http://nodejs.org/) installed

Setting up gulp:

    cd potree_directory
    npm install -g gulp
    npm install --save-dev

## Usage

    gulp build

This will create a single build/js/potree.js file