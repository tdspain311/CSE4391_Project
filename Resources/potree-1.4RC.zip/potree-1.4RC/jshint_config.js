{
	"shadow": true,
	"eqnull": true,
	"laxbreak": true
}